import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


export class AppComponent {
click() {

  alert("Please wait....Working Progress...!!")

}
name = "Ayush";
userName = "Amol";
img1 = "https://media.licdn.com/dms/image/v2/D5603AQELojEFdC4-ng/profile-displayphoto-shrink_200_200/B56ZU.qc_VGUAY-/0/1740513078053?e=2147483647&v=beta&t=-CUOB2VEqCVRzxwiZmFbDC5dcVCXwVcvmSeBoRCTHGE";


showMessage(){
  alert("Congratulations...!!!!!")
}

}
